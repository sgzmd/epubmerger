/**
 * Classes related to making a Book out of a set of .chm (windows help) files.
 */
package nl.siegmann.epublib.chm;